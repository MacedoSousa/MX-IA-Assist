package com.macedxs.mx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
